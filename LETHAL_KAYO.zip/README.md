# LETHAL_KAYO_MODPACK_?

A mod pack I created for my friends and myself. It contains over a hundred mods. Some require a bit of configuration to fit your needs. (In this case, make the adjustments through Lethal Config, and relaunch your game to be sure of their application).

Above all, I improved the core content, adding new things. Like a better HUD, end-game improvements, new scraps and moons... And some delirium as well. The list is above, I'll let you discover it.

I've tried to strike a balance by considering that there must be a countermeasure to the introduction of a punitive rule. (EX : Turrets can spawn outside: a shovel will shut them down. )

I also implemented a lot of cosmetics and outfits. For better or worse, depending on the tastes of your co-workers.
All while trying to remain "lore-friendly" and pleasant to play.

I'll continue to update it as soon as I have time. But I consider it "finished" today.

Feel free to add, disable some mods, transform and re-upload my modpack for your personal use.

I recommend you to share your profile code via Thunderstore, to avoid desynchronization as much as possible, after changing your settings in local.

I hope you will like it, I put a lot of love into it !
It was fun to learn how to master a computer language, and to start doing things in Blender, I continue to correct my mistakes. Sorry if it's visible.

Thanks to the other modders for they work. What a creative community.

Special thanks to Luther and MFDOOM's lofi remixes for keeping me from going crazy.

# USAGE_TIPS_:

Before your game starts, disable the custom hotbar in PototoePet's "[Advanced_Company](https://thunderstore.io/c/lethal-company/p/PotatoePet/AdvancedCompany/)". This option is not compatible with FlipMod's "[Reserved_Slots](https://thunderstore.io/c/lethal-company/p/FlipMods/ReservedItemSlotCore/)".

You should also check/uncheck "LegacyMoonLoading" in the "[Lethal Expansion](https://thunderstore.io/c/lethal-company/p/HolographicWings/LethalExpansion/)" options to solve certain noclip problems.

# YOU_FIND_A_USELESS_MOD_OR_A_BUG_?

[CONTACT_ME](https://steamcommunity.com/profiles/76561198132605584/)

Please, send me a message on steam ! 

PEACE AND PLS LOVE YOURSELF
[BARZ](https://www.youtube.com/watch?v=eDh64IBvQ1Q)

For us, by us. KC.
(AND THE COMPANY)